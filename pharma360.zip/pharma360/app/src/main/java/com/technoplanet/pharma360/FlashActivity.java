package com.technoplanet.pharma360;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class FlashActivity extends AppCompatActivity {

    private LinearLayout logo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flash);

        logo = findViewById(R.id.logo);

        Animation animation = AnimationUtils.loadAnimation(FlashActivity.this, R.anim.flashanim);
        logo.setAnimation(animation);
        animation.start();

        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                Intent i = new Intent(FlashActivity.this,LoginActivity.class);
                startActivity(i);
                finish();

            }
        };

        Timer splash = new Timer();
        splash.schedule(task,4000);
    }
}
